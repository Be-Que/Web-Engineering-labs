$(document).ready(function (e) {

    
$("#submitbtn").click(function(e) {

e.preventDefault();


var name= $("#name").val();
var roll = $("#roll").val();

$.ajax({    

     url: "postform.php", 
     type: "POST",                    
     data: {name:name, roll:roll},                                 
     success: function(data)         
     {
        
        $('#name').val("");
        $('#roll').val("");
     	alert("Inserted successfully");
        //location.reload();
      },  //end success

    error: function(error) {

     console.log(error);
     alert (error);
     alert( JSON.stringify(error) );
    
  }
    });
  }); 
});