<?php

$name=$_POST['name'];
$roll= $_POST['roll'];

print "Welcome ".$name."<br>";
print  "Roll Num: ".$roll."<br>";

?>